/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BookServlet;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy thông tin sách từ request
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        int year = Integer.parseInt(request.getParameter("year"));

        // Tạo đối tượng sách
        Book book = new Book(title, author, year);

        // Lấy danh sách sách từ ServletContext hoặc tạo mới nếu không tồn tại
        HttpSession session = request.getSession();
        ArrayList<Book> bookList = (ArrayList<Book>) session.getAttribute("bookList");
        if (bookList == null) {
            bookList = new ArrayList<>();
        }

        // Thêm sách vào danh sách
        bookList.add(book);

        // Lưu danh sách sách vào ServletContext
        session.setAttribute("bookList", bookList);

        // Chuyển hướng đến trang hiển thị danh sách sách
        response.sendRedirect("bookList.jsp");
    }
}
